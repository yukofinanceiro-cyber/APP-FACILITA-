/* YUKO Facilita — cache do "casco" do app (HTML, ícones e bibliotecas).
   Os dados financeiros NUNCA passam por aqui: chamadas ao Supabase vão direto à rede. */
const VERSAO = 'facilita-v1';
const CASCO = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png', './apple-touch-icon.png'];
const CDN = ['cdn.jsdelivr.net', 'cdnjs.cloudflare.com', 'unpkg.com'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSAO).then(c => c.addAll(CASCO)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(ks => Promise.all(ks.filter(k => k !== VERSAO).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.hostname.endsWith('supabase.co') || url.hostname.endsWith('supabase.in')) return; // dados: sempre rede
  const mesmaOrigem = url.origin === self.location.origin;
  if (req.mode === 'navigate') {                       // páginas: rede primeiro, cache se estiver offline
    e.respondWith(fetch(req).then(r => { caches.open(VERSAO).then(c => c.put('./index.html', r.clone())); return r; })
      .catch(() => caches.match('./index.html')));
    return;
  }
  if (mesmaOrigem || CDN.includes(url.hostname)) {     // arquivos estáticos: cache primeiro, atualiza em segundo plano
    e.respondWith(caches.match(req).then(hit => {
      const rede = fetch(req).then(r => { if (r && (r.ok || r.type === 'opaque')) caches.open(VERSAO).then(c => c.put(req, r.clone())); return r; }).catch(() => hit);
      return hit || rede;
    }));
  }
});
